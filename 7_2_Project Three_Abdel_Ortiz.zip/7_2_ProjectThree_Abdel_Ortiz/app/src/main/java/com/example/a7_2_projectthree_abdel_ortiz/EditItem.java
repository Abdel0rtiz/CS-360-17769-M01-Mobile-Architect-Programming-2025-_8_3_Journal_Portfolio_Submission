package com.example.a7_2_projectthree_abdel_ortiz;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * EditItem Activity
 * ---------------------------------------------------------
 * This screen allows the user to:
 *   - Create a new inventory item
 *   - Edit an existing item
 *   - Delete an item
 *
 * After saving or updating an item, if the quantity is below the
 * low-threshold value, the app attempts to send an SMS alert
 * (only if the user previously granted SMS permission).
 */
public class EditItem extends AppCompatActivity {

    private EditText etItemName, etItemQuantity, etItemDescription;
    private Button btnSave, btnCancel, btnDelete;
    private DatabaseHelper db;
    private long itemId = -1;

    // Threshold for triggering SMS low-stock alert
    private static final int DEFAULT_LOW_THRESHOLD = 5;

    // Default emulator phone number for SMS testing
    private static final String EMULATOR_PHONE = "5554";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        // Initialize DB helper
        db = new DatabaseHelper(this);

        // UI Components
        etItemName        = findViewById(R.id.etItemName);
        etItemQuantity    = findViewById(R.id.etItemQuantity);
        etItemDescription = findViewById(R.id.etItemDescription);
        btnSave           = findViewById(R.id.btnSaveItem);
        btnCancel         = findViewById(R.id.button);
        btnDelete         = findViewById(R.id.btnDelete);

        /**
         * Determine whether we are:
         *   - Editing an existing item (itemId != -1)
         *   - Creating a new one (itemId == -1)
         */
        itemId = getIntent().getLongExtra("item_id", -1);

        if (itemId != -1) {
            // Load existing item into form fields
            loadItem();
        } else {
            // New item → deleting does not make sense
            btnDelete.setVisibility(View.GONE);
        }

        // Action listeners
        btnSave.setOnClickListener(v -> saveItem());
        btnCancel.setOnClickListener(v -> finish());
        btnDelete.setOnClickListener(v -> deleteItem());
    }

    /**
     * Loads data from the database into the UI fields for editing.
     */
    private void loadItem() {
        InventoryItem item = db.getItem(itemId);
        if (item != null) {
            etItemName.setText(item.getName());
            etItemQuantity.setText(String.valueOf(item.getQuantity()));
            etItemDescription.setText(item.getDescription());
        }
    }

    /**
     * Method responsible for validating inputs and saving/updating the item.
     * If the item is new → insert.
     * If the item already exists → update.
     */
    private void saveItem() {
        String name = etItemName.getText().toString().trim();
        String qtyStr = etItemQuantity.getText().toString().trim();
        String desc = etItemDescription.getText().toString().trim();

        // Basic validation
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qtyStr)) {
            Toast.makeText(this, "Name and quantity are required", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        int lowThreshold = DEFAULT_LOW_THRESHOLD;

        if (itemId == -1) {
            // Create a new item
            InventoryItem newItem = new InventoryItem(name, qty, desc, lowThreshold);
            long id = db.addItem(newItem);

            if (id > 0) {
                newItem.setId(id);
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();

                // SMS alert if low stock
                checkAndSendLowStockSms(newItem);

                finish();
            } else {
                Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
            }

        } else {
            // Update existing item
            InventoryItem item = new InventoryItem(itemId, name, qty, desc, lowThreshold);
            int rows = db.updateItem(item);

            if (rows > 0) {
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();

                // SMS alert if low stock
                checkAndSendLowStockSms(item);

                finish();
            } else {
                Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Deletes the item from the database.
     */
    private void deleteItem() {
        if (itemId == -1) {
            finish();
            return;
        }

        int rows = db.deleteItem(itemId);

        if (rows > 0) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    /**
     * Sends a low-stock SMS alert *only if*:
     *   - The item quantity is below the low threshold
     *   - The SEND_SMS permission has been granted
     */
    private void checkAndSendLowStockSms(InventoryItem item) {

        // Do nothing if quantity is not low
        if (item.getQuantity() >= item.getLowThreshold()) {
            return;
        }

        // Check permission before sending SMS
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this, "SMS permission not granted. No alert sent.", Toast.LENGTH_SHORT).show();
            return;
        }

        String msg = "Low inventory alert: " + item.getName() +
                " has only " + item.getQuantity() + " units left.";

        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(EMULATOR_PHONE, null, msg, null, null);

            Toast.makeText(this, "Low stock SMS alert sent", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Error sending SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
