package com.example.a7_2_projectthree_abdel_ortiz;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Main login activity.
 * Users can sign in if registered, or open a floating dialog to create an account.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvSignup;

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin   = findViewById(R.id.btnLogin);
        tvSignup   = findViewById(R.id.tvSignup);

        // Login no longer creates users; only verifies existing ones
        btnLogin.setOnClickListener(v -> handleLogin());

        // Creates a clickable "Sign Up Now" text
        setupSignupText();
    }

    /**
     * Handles login validation.
     * Only users that previously signed up may log in.
     */
    private void handleLogin() {
        String user = etUsername.getText().toString().trim();
        String pass = etPassword.getText().toString().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean exists = db.userExists(user);

        if (!exists) {
            Toast.makeText(this,
                    "User does not exist. Please sign up first.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // User exists → validate password
        if (db.checkUser(user, pass)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            goToInventory();
        } else {
            Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Creates the "Don’t have an account? Sign Up Now" clickable span.
     */
    private void setupSignupText() {
        String fullText = "Don’t have an account?  Sign Up Now";
        SpannableString ss = new SpannableString(fullText);

        int start = fullText.indexOf("Sign Up Now");
        int end = start + "Sign Up Now".length();

        ClickableSpan signupClick = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                openSignupDialog();
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(getResources().getColor(R.color.blue_primary));
                ds.setUnderlineText(false);
            }
        };

        ss.setSpan(signupClick, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvSignup.setMovementMethod(LinkMovementMethod.getInstance());
        tvSignup.setText(ss);
    }

    /**
     * Opens a floating dialog for creating new user accounts.
     */
    private void openSignupDialog() {
        Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog_signup);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        EditText etNewUsername = dialog.findViewById(R.id.etNewUsername);
        EditText etNewPassword = dialog.findViewById(R.id.etNewPassword);
        Button btnCreate       = dialog.findViewById(R.id.btnCreateAccount);
        Button btnCancel       = dialog.findViewById(R.id.btnCancelSignup);

        btnCreate.setOnClickListener(v -> {
            String newUser = etNewUsername.getText().toString().trim();
            String newPass = etNewPassword.getText().toString().trim();

            if (newUser.isEmpty() || newPass.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.userExists(newUser)) {
                Toast.makeText(MainActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                return;
            }

            long result = db.addUser(newUser, newPass);

            if (result > 0) {
                Toast.makeText(MainActivity.this, "Account created!", Toast.LENGTH_SHORT).show();
                etUsername.setText(newUser);
                etPassword.setText(newPass);
                dialog.dismiss();
            } else {
                Toast.makeText(MainActivity.this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    /**
     * Opens the Inventory screen.
     */
    private void goToInventory() {
        Intent intent = new Intent(MainActivity.this, Inventory.class);
        startActivity(intent);
        finish();
    }
}
