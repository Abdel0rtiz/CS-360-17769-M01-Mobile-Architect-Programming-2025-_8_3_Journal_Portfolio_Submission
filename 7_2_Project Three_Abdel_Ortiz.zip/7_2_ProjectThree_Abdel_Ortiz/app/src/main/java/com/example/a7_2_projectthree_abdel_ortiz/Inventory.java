package com.example.a7_2_projectthree_abdel_ortiz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Inventory Activity
 * ---------------------------------------------------------
 * This screen displays all inventory items stored in the database.
 * Users can:
 *   - View the item list
 *   - Add a new item
 *   - Edit or delete items (tapping a row opens EditItem)
 *   - Navigate to SMS permission screen
 *   - Log out and return to the login screen
 *
 * A RecyclerView is used along with the ItemInventory adapter
 * to show the list of InventoryItem objects.
 */
public class Inventory extends AppCompatActivity {

    private RecyclerView rvInventory;
    private Button btnAddItem, btnLogout, btnSms;
    private ItemInventory adapter;
    private DatabaseHelper db;
    private TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize the database helper
        db = new DatabaseHelper(this);

        // UI references
        rvInventory = findViewById(R.id.rvInventory);
        btnAddItem  = findViewById(R.id.btnAddItem);
        btnLogout   = findViewById(R.id.btnLogout);
        btnSms      = findViewById(R.id.btnSms);
        tvTitle     = findViewById(R.id.tvTitle);

        // Setup RecyclerView with vertical list
        rvInventory.setLayoutManager(new LinearLayoutManager(this));

        // Load all items from database and attach adapter
        adapter = new ItemInventory(this, db.getAllItems());
        rvInventory.setAdapter(adapter);

        /**
         * Add Item Button:
         * Opens EditItem activity in "new item" mode (no ID provided).
         */
        btnAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, EditItem.class);
            startActivity(intent);
        });

        /**
         * Logout Button:
         * Sends the user back to the login screen.
         * Clears the activity stack so the user cannot return with the Back button.
         */
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        /**
         * SMS Permission Button:
         * Opens the screen that allows the user to check and request SMS permissions.
         */
        btnSms.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, SmsPermission.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        /**
         * When returning to this screen (e.g., after editing an item),
         * refresh the item list so the RecyclerView displays the latest data.
         */
        List<InventoryItem> items = db.getAllItems();
        adapter.setItems(items);
    }
}
