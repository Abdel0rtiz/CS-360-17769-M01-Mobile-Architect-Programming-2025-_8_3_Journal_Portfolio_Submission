package com.example.a7_2_projectthree_abdel_ortiz;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView.Adapter responsible for displaying a list of InventoryItem objects
 * in the inventory screen.
 *
 * Each row is represented by activity_item_inventory.xml and shows:
 *  - Item name
 *  - Item quantity
 *
 * When the user taps a row, it opens EditItem activity to edit or delete that item.
 */
public class ItemInventory extends RecyclerView.Adapter<ItemInventory.ViewHolder> {

    private Context context;
    private List<InventoryItem> items;

    /**
     * Constructor for the adapter.
     *
     * @param context Activity or fragment context used to inflate views and start activities.
     * @param items   Initial list of inventory items to display.
     */
    public ItemInventory(Context context, List<InventoryItem> items) {
        this.context = context;
        this.items = items;
    }

    /**
     * Updates the adapter data with a new list of items and refreshes the UI.
     *
     * @param newItems New list of InventoryItem objects.
     */
    public void setItems(List<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout that represents a single row/card in the RecyclerView
        View view = LayoutInflater.from(context)
                .inflate(R.layout.activity_item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the item for the current position
        InventoryItem item = items.get(position);

        // Bind item data to the UI elements
        holder.tvName.setText(item.getName());
        holder.tvQty.setText(String.valueOf(item.getQuantity()));

        // When the user taps the entire card, open EditItem to edit or delete this item
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditItem.class);
            intent.putExtra("item_id", item.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        // Safely handle null list (e.g., before data is loaded)
        return items != null ? items.size() : 0;
    }

    /**
     * ViewHolder class that holds the references to the views for each row.
     * It improves performance by avoiding repeated findViewById calls.
     */
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvQty;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvItemName);
            tvQty = itemView.findViewById(R.id.tvItemQuantity);
        }
    }
}
