package com.example.a7_2_projectthree_abdel_ortiz;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Activity that manages SMS permission checking and requesting.
 * It allows the user to manually check or request SEND_SMS permission.
 */
public class SmsPermission extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private TextView tvPermissionStatus;
    private Button btnCheckPermission, btnRequestPermission, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // UI initialization
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        btnCheckPermission = findViewById(R.id.btnCheckPermission);
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnBack = findViewById(R.id.btnBack);

        // Permission is verified ONLY when the user clicks "Check Permission"
        btnCheckPermission.setOnClickListener(v -> checkPermissionStatus());

        // Permission is requested ONLY when the user clicks "Request Permission"
        btnRequestPermission.setOnClickListener(v -> requestSmsPermission());

        btnBack.setOnClickListener(v -> finish());
    }

    /**
     * Checks if SEND_SMS permission is granted,
     * and updates the UI accordingly.
     */
    private void checkPermissionStatus() {
        if (hasSmsPermission()) {
            tvPermissionStatus.setText("SMS Permission: GRANTED");
            tvPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            tvPermissionStatus.setText("SMS Permission: DENIED");
            tvPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }

    /**
     * Requests SEND_SMS permission if not already granted.
     */
    private void requestSmsPermission() {
        if (hasSmsPermission()) {
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            return;
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE
        );
    }

    /**
     * @return true if SEND_SMS permission is granted.
     */
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Called when the user responds to the permission request dialog.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                tvPermissionStatus.setText("SMS Permission: GRANTED");
                tvPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                tvPermissionStatus.setText("SMS Permission: DENIED");
                tvPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            }
        }
    }
}
