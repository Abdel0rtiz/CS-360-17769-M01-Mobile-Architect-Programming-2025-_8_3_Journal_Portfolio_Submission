package com.example.a7_2_projectthree_abdel_ortiz;

/**
 * Represents a single inventory item stored in the database.
 * This model class is used across the app to pass item information
 * between activities and database operations.
 *
 * Each item contains:
 *  - id: unique identifier in the database
 *  - name: name of the item
 *  - quantity: current quantity available
 *  - description: optional notes
 *  - lowThreshold: minimum quantity before triggering an SMS alert
 */
public class InventoryItem {

    private long id;
    private String name;
    private int quantity;
    private String description;
    private int lowThreshold;

    /**
     * Default constructor (required for some frameworks or serialization).
     */
    public InventoryItem() {}

    /**
     * Full constructor used when loading an existing item from the database.
     */
    public InventoryItem(long id, String name, int quantity, String description, int lowThreshold) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.description = description;
        this.lowThreshold = lowThreshold;
    }

    /**
     * Constructor used when creating a new item before it is saved to the database.
     * The ID is assigned later when the database insert returns its row ID.
     */
    public InventoryItem(String name, int quantity, String description, int lowThreshold) {
        this(-1, name, quantity, description, lowThreshold);
    }

    // ---------- GETTERS & SETTERS ----------

    public long getId() { return id; }

    /**
     * Sets the database ID after an item is inserted.
     */
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }

    public void setQuantity(int quantity) { this.quantity = quantity; }

    /**
     * Returns an empty string instead of null to avoid crashes in UI components.
     */
    public String getDescription() { return description != null ? description : ""; }

    public void setDescription(String description) { this.description = description; }

    public int getLowThreshold() { return lowThreshold; }

    public void setLowThreshold(int lowThreshold) { this.lowThreshold = lowThreshold; }
}
