package com.example.a7_2_projectthree_abdel_ortiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper
 * --------------------------------------------------------------------
 * This class manages all SQLite database operations for the app,
 * including:
 *   - Creating the database structure
 *   - Managing user accounts
 *   - Storing and retrieving inventory items
 *
 * It contains two tables:
 *   1) users    → login system
 *   2) items    → inventory management
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database metadata
    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 1;

    // USER TABLE -----------------------------------
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // ITEM TABLE -----------------------------------
    public static final String TABLE_ITEMS = "items";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_DESC = "description";
    public static final String COL_ITEM_LOW = "low_threshold";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    /**
     * Called automatically when the database is first created.
     * This method builds both the USERS and ITEMS tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create USERS table
        db.execSQL("CREATE TABLE " + TABLE_USERS + "(" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD + " TEXT NOT NULL)");

        // Create ITEMS table
        db.execSQL("CREATE TABLE " + TABLE_ITEMS + "(" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT NOT NULL, " +
                COL_ITEM_QTY + " INTEGER NOT NULL, " +
                COL_ITEM_DESC + " TEXT, " +
                COL_ITEM_LOW + " INTEGER DEFAULT 5)");
    }

    /**
     * Called whenever the database version increases.
     * Used for updating table structures safely.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop all tables and recreate them (simple migration strategy)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // ========================================================================
    // USER OPERATIONS (LOGIN SYSTEM)
    // ========================================================================

    /**
     * Checks whether a user with the given username already exists.
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null, COL_USERNAME + "=?",
                new String[]{username}, null, null, null);

        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    /**
     * Validates a username/password combination.
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(TABLE_USERS, null,
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);

        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    /**
     * Registers a new user in the database.
     */
    public long addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);

        return db.insert(TABLE_USERS, null, cv);
    }

    // ========================================================================
    // INVENTORY OPERATIONS (CRUD FOR ITEMS)
    // ========================================================================

    /**
     * Adds a new inventory item into the database.
     */
    public long addItem(InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_ITEM_NAME, item.getName());
        cv.put(COL_ITEM_QTY, item.getQuantity());
        cv.put(COL_ITEM_DESC, item.getDescription());
        cv.put(COL_ITEM_LOW, item.getLowThreshold());

        return db.insert(TABLE_ITEMS, null, cv);
    }

    /**
     * Updates an existing inventory item.
     */
    public int updateItem(InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_ITEM_NAME, item.getName());
        cv.put(COL_ITEM_QTY, item.getQuantity());
        cv.put(COL_ITEM_DESC, item.getDescription());
        cv.put(COL_ITEM_LOW, item.getLowThreshold());

        return db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?",
                new String[]{String.valueOf(item.getId())});
    }

    /**
     * Deletes an item by its ID.
     */
    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    /**
     * Retrieves a single inventory item from the database by its ID.
     */
    public InventoryItem getItem(long id) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(TABLE_ITEMS, null, COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);

        if (c.moveToFirst()) {
            InventoryItem item = cursorToItem(c);
            c.close();
            return item;
        }

        c.close();
        return null;
    }

    /**
     * Retrieves all inventory items, sorted alphabetically by name.
     */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(TABLE_ITEMS, null,
                null, null, null, null, COL_ITEM_NAME + " ASC");

        while (c.moveToNext()) {
            list.add(cursorToItem(c));
        }

        c.close();
        return list;
    }

    /**
     * Helper method that converts a database row (Cursor)
     * into a usable InventoryItem object.
     */
    private InventoryItem cursorToItem(Cursor c) {
        long id = c.getLong(c.getColumnIndexOrThrow(COL_ITEM_ID));
        String name = c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME));
        int qty = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_QTY));
        String desc = c.getString(c.getColumnIndexOrThrow(COL_ITEM_DESC));
        int low = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_LOW));

        return new InventoryItem(id, name, qty, desc, low);
    }
}
