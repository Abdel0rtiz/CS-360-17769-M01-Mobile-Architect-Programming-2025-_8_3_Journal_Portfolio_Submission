package com.example.a5_3_project_tow_abdel_ortiz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private Context context;
    private List<InventoryItem> items;
    private OnItemActions listener;

    public interface OnItemActions {
        void onDeleteClicked(InventoryItem item);
        void onItemClicked(InventoryItem item);
    }

    public InventoryAdapter(Context context, List<InventoryItem> items, OnItemActions listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    @Override
    public InventoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.activity_item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(InventoryViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.tvName.setText(item.name);
        holder.tvQty.setText(String.valueOf(item.quantity));

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDeleteClicked(item);
        });

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClicked(item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void updateData(List<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvQty;
        ImageButton btnDelete;

        public InventoryViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvItemName);
            tvQty = itemView.findViewById(R.id.tvItemQuantity);
            btnDelete = itemView.findViewById(R.id.btnDeleteItem);
        }
    }
}
