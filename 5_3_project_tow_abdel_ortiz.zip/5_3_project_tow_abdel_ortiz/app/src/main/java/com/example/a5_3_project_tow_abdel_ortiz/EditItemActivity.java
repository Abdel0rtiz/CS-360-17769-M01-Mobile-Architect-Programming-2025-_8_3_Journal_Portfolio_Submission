package com.example.a5_3_project_tow_abdel_ortiz;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    EditText etItemName, etItemQuantity, etItemDescription;
    Button btnSave;
    DatabaseHelper dbHelper;
    int itemId = -1;  // si es -1 significa que es un nuevo item

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        dbHelper = new DatabaseHelper(this);

        // Enlazar vistas con IDs REALES del XML
        etItemName = findViewById(R.id.etItemName);
        etItemQuantity = findViewById(R.id.etItemQty);
        etItemDescription = findViewById(R.id.etItemDesc);
        btnSave = findViewById(R.id.btnSave);

        // Obtener ID si venimos de edición
        if (getIntent().hasExtra("itemId")) {
            itemId = getIntent().getIntExtra("itemId", -1);
            etItemName.setText(getIntent().getStringExtra("name"));
            etItemQuantity.setText(String.valueOf(getIntent().getIntExtra("qty", 0)));
            etItemDescription.setText(getIntent().getStringExtra("desc"));
        }

        // BOTÓN GUARDAR
        btnSave.setOnClickListener(v -> saveItem());
    }

    private void saveItem() {
        String name = etItemName.getText().toString().trim();
        String qtyText = etItemQuantity.getText().toString().trim();
        String desc = etItemDescription.getText().toString().trim();

        if (name.isEmpty() || qtyText.isEmpty()) {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty = Integer.parseInt(qtyText);

        boolean success;

        if (itemId == -1) {
            // Crear nuevo item
            success = dbHelper.insertItem(name, qty, desc);
            Toast.makeText(this, success ? "Item added" : "Error adding item", Toast.LENGTH_SHORT).show();
        } else {
            // Actualizar item existente
            success = dbHelper.updateItem(itemId, name, qty, desc);
            Toast.makeText(this, success ? "Item updated" : "Error updating item", Toast.LENGTH_SHORT).show();
        }

        if (success) finish();
    }
}
