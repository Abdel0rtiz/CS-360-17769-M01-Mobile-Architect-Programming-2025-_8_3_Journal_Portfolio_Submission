package com.example.a5_3_project_tow_abdel_ortiz;

public class InventoryItem {
    public long id;
    public String name;
    public int quantity;
    public String description;

    public InventoryItem(long id, String name, int quantity, String description) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.description = description;
    }
}
