package com.example.a5_3_project_tow_abdel_ortiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST = 100;

    private Button btnCheck, btnRequest;
    private TextView tvStatus;
    private BottomNavigationView bottomNav;

    private String testPhone = "5554";
    private String testMessage = "Low stock alert from Warehouse App";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        btnCheck = findViewById(R.id.btnCheckSms);
        btnRequest = findViewById(R.id.btnRequestSms);
        tvStatus = findViewById(R.id.tvSmsStatus);
        bottomNav = findViewById(R.id.bottomNav);

        btnCheck.setOnClickListener(view -> updatePermissionStatus());
        btnRequest.setOnClickListener(view -> requestSmsPermission());

        // Bottom navigation
        bottomNav.setSelectedItemId(R.id.nav_sms);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_inventory) {
                startActivity(new Intent(SmsPermissionActivity.this, InventoryActivity.class));
                return true;
            } else if (id == R.id.nav_sms) {
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(SmsPermissionActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }

    private void updatePermissionStatus() {
        if (hasSmsPermission()) {
            tvStatus.setText("Permission status: GRANTED");
        } else {
            tvStatus.setText("Permission status: DENIED");
        }
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        if (!hasSmsPermission()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST);
        } else {
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                tvStatus.setText("Permission status: GRANTED");
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                sendTestSms();
            } else {
                tvStatus.setText("Permission status: DENIED");
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendTestSms() {
        if (!hasSmsPermission()) return;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(testPhone, null, testMessage, null, null);
            Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error sending SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
