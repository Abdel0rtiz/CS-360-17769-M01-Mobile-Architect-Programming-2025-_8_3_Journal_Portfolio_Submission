package com.example.a5_3_project_tow_abdel_ortiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnItemActions {

    private RecyclerView rvInventory;
    private FloatingActionButton fabAdd;
    private BottomNavigationView bottomNav;

    private DatabaseHelper dbHelper;
    private InventoryAdapter adapter;
    private List<InventoryItem> itemList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);

        rvInventory = findViewById(R.id.rvInventory);
        fabAdd = findViewById(R.id.fabAdd);
        bottomNav = findViewById(R.id.bottomNav);

        rvInventory.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new InventoryAdapter(this, itemList, this);
        rvInventory.setAdapter(adapter);

        loadItems();

        fabAdd.setOnClickListener(view -> {
            Intent intent = new Intent(InventoryActivity.this, EditItemActivity.class);
            startActivity(intent);
        });

        // Bottom navigation
        bottomNav.setSelectedItemId(R.id.nav_inventory);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_inventory) {
                // ya estamos aquí
                return true;
            } else if (id == R.id.nav_sms) {
                startActivity(new Intent(InventoryActivity.this, SmsPermissionActivity.class));
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(InventoryActivity.this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }

    private void loadItems() {
        itemList.clear();
        Cursor cursor = dbHelper.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_QTY));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_DESC));
                itemList.add(new InventoryItem(id, name, qty, desc));
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.updateData(itemList);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    @Override
    public void onDeleteClicked(InventoryItem item) {
        dbHelper.deleteItem(item.id);
        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        loadItems();
    }

    @Override
    public void onItemClicked(InventoryItem item) {
        Intent intent = new Intent(InventoryActivity.this, EditItemActivity.class);
        intent.putExtra("ITEM_ID", item.id);
        intent.putExtra("ITEM_NAME", item.name);
        intent.putExtra("ITEM_QTY", item.quantity);
        intent.putExtra("ITEM_DESC", item.description);
        startActivity(intent);
    }
}
