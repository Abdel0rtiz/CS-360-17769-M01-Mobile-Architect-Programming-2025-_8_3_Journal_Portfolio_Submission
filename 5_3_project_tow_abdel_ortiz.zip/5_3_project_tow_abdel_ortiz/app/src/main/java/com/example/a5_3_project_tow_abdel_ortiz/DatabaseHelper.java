package com.example.a5_3_project_tow_abdel_ortiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Nombre de la base de datos
    public static final String DATABASE_NAME = "warehouse.db";

    // TABLA DE USUARIOS
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // TABLA DE INVENTARIO
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_DESC = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Crear tabla de usuarios
        db.execSQL("CREATE TABLE " + TABLE_USERS +
                " (" + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE, "
                + COL_PASSWORD + " TEXT)");

        // Crear tabla de inventario
        db.execSQL("CREATE TABLE " + TABLE_INVENTORY +
                " (" + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT, "
                + COL_ITEM_QTY + " INTEGER, "
                + COL_ITEM_DESC + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ---------------------------------------------------------
    // USUARIOS (LOGIN)
    // ---------------------------------------------------------

    // Crear usuario
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    // Verificar usuario para login
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " +
                        COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // ---------------------------------------------------------
    // INVENTARIO
    // ---------------------------------------------------------

    // Insertar ítem base
    public boolean insertItem(String name, int qty, String desc) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_ITEM_NAME, name);
        cv.put(COL_ITEM_QTY, qty);
        cv.put(COL_ITEM_DESC, desc);

        long result = db.insert(TABLE_INVENTORY, null, cv);
        return result != -1;
    }

    // Alias que usa EditItemActivity: addItem(...)
    public boolean addItem(String name, int qty, String desc) {
        return insertItem(name, qty, desc);
    }

    // Actualizar ítem (id como long para que acepte itemId y item.id)
    public boolean updateItem(long id, String name, int qty, String desc) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_ITEM_NAME, name);
        cv.put(COL_ITEM_QTY, qty);
        cv.put(COL_ITEM_DESC, desc);

        int result = db.update(
                TABLE_INVENTORY,
                cv,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );
        return result > 0;
    }

    // Eliminar ítem (id como long también)
    public boolean deleteItem(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );
        return result > 0;
    }

    // Obtener todos los ítems del inventario
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }
}
